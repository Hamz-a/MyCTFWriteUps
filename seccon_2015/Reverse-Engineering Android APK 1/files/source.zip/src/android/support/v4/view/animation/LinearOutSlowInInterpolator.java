// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.animation;


// Referenced classes of package android.support.v4.view.animation:
//            LookupTableInterpolator

public class LinearOutSlowInInterpolator extends LookupTableInterpolator
{

    private static final float VALUES[] = {
        0.0F, 0.0222F, 0.0424F, 0.0613F, 0.0793F, 0.0966F, 0.1132F, 0.1293F, 0.1449F, 0.16F, 
        0.1747F, 0.189F, 0.2029F, 0.2165F, 0.2298F, 0.2428F, 0.2555F, 0.268F, 0.2802F, 0.2921F, 
        0.3038F, 0.3153F, 0.3266F, 0.3377F, 0.3486F, 0.3592F, 0.3697F, 0.3801F, 0.3902F, 0.4002F, 
        0.41F, 0.4196F, 0.4291F, 0.4385F, 0.4477F, 0.4567F, 0.4656F, 0.4744F, 0.4831F, 0.4916F, 
        0.5F, 0.5083F, 0.5164F, 0.5245F, 0.5324F, 0.5402F, 0.5479F, 0.5555F, 0.5629F, 0.5703F, 
        0.5776F, 0.5847F, 0.5918F, 0.5988F, 0.6057F, 0.6124F, 0.6191F, 0.6257F, 0.6322F, 0.6387F, 
        0.645F, 0.6512F, 0.6574F, 0.6635F, 0.6695F, 0.6754F, 0.6812F, 0.687F, 0.6927F, 0.6983F, 
        0.7038F, 0.7093F, 0.7147F, 0.72F, 0.7252F, 0.7304F, 0.7355F, 0.7406F, 0.7455F, 0.7504F, 
        0.7553F, 0.76F, 0.7647F, 0.7694F, 0.774F, 0.7785F, 0.7829F, 0.7873F, 0.7917F, 0.7959F, 
        0.8002F, 0.8043F, 0.8084F, 0.8125F, 0.8165F, 0.8204F, 0.8243F, 0.8281F, 0.8319F, 0.8356F, 
        0.8392F, 0.8429F, 0.8464F, 0.8499F, 0.8534F, 0.8568F, 0.8601F, 0.8634F, 0.8667F, 0.8699F, 
        0.8731F, 0.8762F, 0.8792F, 0.8823F, 0.8852F, 0.8882F, 0.891F, 0.8939F, 0.8967F, 0.8994F, 
        0.9021F, 0.9048F, 0.9074F, 0.91F, 0.9125F, 0.915F, 0.9174F, 0.9198F, 0.9222F, 0.9245F, 
        0.9268F, 0.929F, 0.9312F, 0.9334F, 0.9355F, 0.9376F, 0.9396F, 0.9416F, 0.9436F, 0.9455F, 
        0.9474F, 0.9492F, 0.951F, 0.9528F, 0.9545F, 0.9562F, 0.9579F, 0.9595F, 0.9611F, 0.9627F, 
        0.9642F, 0.9657F, 0.9672F, 0.9686F, 0.97F, 0.9713F, 0.9726F, 0.9739F, 0.9752F, 0.9764F, 
        0.9776F, 0.9787F, 0.9798F, 0.9809F, 0.982F, 0.983F, 0.984F, 0.9849F, 0.9859F, 0.9868F, 
        0.9876F, 0.9885F, 0.9893F, 0.99F, 0.9908F, 0.9915F, 0.9922F, 0.9928F, 0.9934F, 0.994F, 
        0.9946F, 0.9951F, 0.9956F, 0.9961F, 0.9966F, 0.997F, 0.9974F, 0.9977F, 0.9981F, 0.9984F, 
        0.9987F, 0.9989F, 0.9992F, 0.9994F, 0.9995F, 0.9997F, 0.9998F, 0.9999F, 0.9999F, 1.0F, 
        1.0F
    };

    public LinearOutSlowInInterpolator()
    {
        super(VALUES);
    }

    public volatile float getInterpolation(float f)
    {
        return super.getInterpolation(f);
    }

}
