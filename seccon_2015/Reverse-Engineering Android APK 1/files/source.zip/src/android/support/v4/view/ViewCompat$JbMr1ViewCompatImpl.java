// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

// Referenced classes of package android.support.v4.view:
//            ViewCompat, ViewCompatJellybeanMr1

static class  extends 
{

    public int getLabelFor(View view)
    {
        return ViewCompatJellybeanMr1.getLabelFor(view);
    }

    public int getLayoutDirection(View view)
    {
        return ViewCompatJellybeanMr1.getLayoutDirection(view);
    }

    public int getPaddingEnd(View view)
    {
        return ViewCompatJellybeanMr1.getPaddingEnd(view);
    }

    public int getPaddingStart(View view)
    {
        return ViewCompatJellybeanMr1.getPaddingStart(view);
    }

    public int getWindowSystemUiVisibility(View view)
    {
        return ViewCompatJellybeanMr1.getWindowSystemUiVisibility(view);
    }

    public boolean isPaddingRelative(View view)
    {
        return ViewCompatJellybeanMr1.isPaddingRelative(view);
    }

    public void setLabelFor(View view, int i)
    {
        ViewCompatJellybeanMr1.setLabelFor(view, i);
    }

    public void setLayerPaint(View view, Paint paint)
    {
        ViewCompatJellybeanMr1.setLayerPaint(view, paint);
    }

    public void setLayoutDirection(View view, int i)
    {
        ViewCompatJellybeanMr1.setLayoutDirection(view, i);
    }

    public void setPaddingRelative(View view, int i, int j, int k, int l)
    {
        ViewCompatJellybeanMr1.setPaddingRelative(view, i, j, k, l);
    }

    ()
    {
    }
}
