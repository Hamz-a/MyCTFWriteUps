// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;

import android.graphics.Rect;

// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityWindowInfoCompat, AccessibilityWindowInfoCompatApi21

private static class <init> extends <init>
{

    public void getBoundsInScreen(Object obj, Rect rect)
    {
        AccessibilityWindowInfoCompatApi21.getBoundsInScreen(obj, rect);
    }

    public Object getChild(Object obj, int i)
    {
        return AccessibilityWindowInfoCompatApi21.getChild(obj, i);
    }

    public int getChildCount(Object obj)
    {
        return AccessibilityWindowInfoCompatApi21.getChildCount(obj);
    }

    public int getId(Object obj)
    {
        return AccessibilityWindowInfoCompatApi21.getId(obj);
    }

    public int getLayer(Object obj)
    {
        return AccessibilityWindowInfoCompatApi21.getLayer(obj);
    }

    public Object getParent(Object obj)
    {
        return AccessibilityWindowInfoCompatApi21.getParent(obj);
    }

    public Object getRoot(Object obj)
    {
        return AccessibilityWindowInfoCompatApi21.getRoot(obj);
    }

    public int getType(Object obj)
    {
        return AccessibilityWindowInfoCompatApi21.getType(obj);
    }

    public boolean isAccessibilityFocused(Object obj)
    {
        return AccessibilityWindowInfoCompatApi21.isAccessibilityFocused(obj);
    }

    public boolean isActive(Object obj)
    {
        return AccessibilityWindowInfoCompatApi21.isActive(obj);
    }

    public boolean isFocused(Object obj)
    {
        return AccessibilityWindowInfoCompatApi21.isFocused(obj);
    }

    public Object obtain()
    {
        return AccessibilityWindowInfoCompatApi21.obtain();
    }

    public Object obtain(Object obj)
    {
        return AccessibilityWindowInfoCompatApi21.obtain(obj);
    }

    public void recycle(Object obj)
    {
        AccessibilityWindowInfoCompatApi21.recycle(obj);
    }

    private ()
    {
        super(null);
    }

    init>(init> init>)
    {
        this();
    }
}
