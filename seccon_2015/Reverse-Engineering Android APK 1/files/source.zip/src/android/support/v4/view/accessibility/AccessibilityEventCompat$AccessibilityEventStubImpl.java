// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;

import android.view.accessibility.AccessibilityEvent;

// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityEventCompat

static class pl
    implements pl
{

    public void appendRecord(AccessibilityEvent accessibilityevent, Object obj)
    {
    }

    public int getContentChangeTypes(AccessibilityEvent accessibilityevent)
    {
        return 0;
    }

    public Object getRecord(AccessibilityEvent accessibilityevent, int i)
    {
        return null;
    }

    public int getRecordCount(AccessibilityEvent accessibilityevent)
    {
        return 0;
    }

    public void setContentChangeTypes(AccessibilityEvent accessibilityevent, int i)
    {
    }

    pl()
    {
    }
}
