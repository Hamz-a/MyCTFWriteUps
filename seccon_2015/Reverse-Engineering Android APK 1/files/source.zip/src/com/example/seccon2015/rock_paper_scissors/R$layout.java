// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.seccon2015.rock_paper_scissors;


// Referenced classes of package com.example.seccon2015.rock_paper_scissors:
//            R

public static final class _cls9
{

    public static final int abc_action_bar_title_item = 0x7f040000;
    public static final int abc_action_bar_up_container = 0x7f040001;
    public static final int abc_action_bar_view_list_nav_layout = 0x7f040002;
    public static final int abc_action_menu_item_layout = 0x7f040003;
    public static final int abc_action_menu_layout = 0x7f040004;
    public static final int abc_action_mode_bar = 0x7f040005;
    public static final int abc_action_mode_close_item_material = 0x7f040006;
    public static final int abc_activity_chooser_view = 0x7f040007;
    public static final int abc_activity_chooser_view_list_item = 0x7f040008;
    public static final int abc_alert_dialog_material = 0x7f040009;
    public static final int abc_dialog_title_material = 0x7f04000a;
    public static final int abc_expanded_menu_layout = 0x7f04000b;
    public static final int abc_list_menu_item_checkbox = 0x7f04000c;
    public static final int abc_list_menu_item_icon = 0x7f04000d;
    public static final int abc_list_menu_item_layout = 0x7f04000e;
    public static final int abc_list_menu_item_radio = 0x7f04000f;
    public static final int abc_popup_menu_item_layout = 0x7f040010;
    public static final int abc_screen_content_include = 0x7f040011;
    public static final int abc_screen_simple = 0x7f040012;
    public static final int abc_screen_simple_overlay_action_mode = 0x7f040013;
    public static final int abc_screen_toolbar = 0x7f040014;
    public static final int abc_search_dropdown_item_icons_2line = 0x7f040015;
    public static final int abc_search_view = 0x7f040016;
    public static final int abc_select_dialog_material = 0x7f040017;
    public static final int activity_main = 0x7f040018;
    public static final int notification_media_action = 0x7f040019;
    public static final int notification_media_cancel_action = 0x7f04001a;
    public static final int notification_template_big_media = 0x7f04001b;
    public static final int notification_template_big_media_narrow = 0x7f04001c;
    public static final int notification_template_lines = 0x7f04001d;
    public static final int notification_template_media = 0x7f04001e;
    public static final int notification_template_part_chronometer = 0x7f04001f;
    public static final int notification_template_part_time = 0x7f040020;
    public static final int select_dialog_item_material = 0x7f040021;
    public static final int select_dialog_multichoice_material = 0x7f040022;
    public static final int select_dialog_singlechoice_material = 0x7f040023;
    public static final int support_simple_spinner_dropdown_item = 0x7f040024;

    public _cls9()
    {
    }
}
