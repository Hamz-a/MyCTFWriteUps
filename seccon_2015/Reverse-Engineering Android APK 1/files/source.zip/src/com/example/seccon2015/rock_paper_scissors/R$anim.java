// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.seccon2015.rock_paper_scissors;


// Referenced classes of package com.example.seccon2015.rock_paper_scissors:
//            R

public static final class 
{

    public static final int abc_fade_in = 0x7f050000;
    public static final int abc_fade_out = 0x7f050001;
    public static final int abc_grow_fade_in_from_bottom = 0x7f050002;
    public static final int abc_popup_enter = 0x7f050003;
    public static final int abc_popup_exit = 0x7f050004;
    public static final int abc_shrink_fade_out_from_bottom = 0x7f050005;
    public static final int abc_slide_in_bottom = 0x7f050006;
    public static final int abc_slide_in_top = 0x7f050007;
    public static final int abc_slide_out_bottom = 0x7f050008;
    public static final int abc_slide_out_top = 0x7f050009;

    public ()
    {
    }
}
